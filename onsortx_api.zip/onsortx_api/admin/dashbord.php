<?php
include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Récupérer les statistiques
$stats_query = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE is_verified = 1) as verified_users,
    (SELECT COUNT(*) FROM users WHERE created_at >= CURDATE()) as today_registrations,
    (SELECT COUNT(*) FROM user_sessions WHERE is_active = 1 AND expires_at > NOW()) as active_sessions";
$stats_stmt = $db->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer les derniers utilisateurs
$recent_users_query = "SELECT * FROM users ORDER BY created_at DESC LIMIT 10";
$recent_users_stmt = $db->prepare($recent_users_query);
$recent_users_stmt->execute();
$recent_users = $recent_users_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>OnSortX - Administration</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        .stats { display: flex; gap: 20px; margin-bottom: 30px; }
        .stat-box { 
            background: #f5f5f5; 
            padding: 20px; 
            border-radius: 8px; 
            text-align: center;
            min-width: 150px;
        }
        .stat-number { font-size: 24px; font-weight: bold; color: #E6B800; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        .status-active { color: green; }
        .status-inactive { color: red; }
    </style>
</head>
<body>
    <h1>🍹 OnSortX - Tableau de bord</h1>
    
    <div class="stats">
        <div class="stat-box">
            <div class="stat-number"><?php echo $stats['total_users']; ?></div>
            <div>Utilisateurs total</div>
        </div>
        <div class="stat-box">
            <div class="stat-number"><?php echo $stats['verified_users']; ?></div>
            <div>Utilisateurs vérifiés</div>
        </div>
        <div class="stat-box">
            <div class="stat-number"><?php echo $stats['today_registrations']; ?></div>
            <div>Inscriptions aujourd'hui</div>
        </div>
        <div class="stat-box">
            <div class="stat-number"><?php echo $stats['active_sessions']; ?></div>
            <div>Sessions actives</div>
        </div>
    </div>
    
    <h2>Derniers utilisateurs inscrits</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nom complet</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Statut</th>
            <th>Date d'inscription</th>
        </tr>
        <?php foreach($recent_users as $user): ?>
        <tr>
            <td><?php echo $user['id']; ?></td>
            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo $user['phone'] ?: 'Non renseigné'; ?></td>
            <td class="<?php echo $user['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                <?php echo $user['is_active'] ? 'Actif' : 'Inactif'; ?>
            </td>
            <td><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>