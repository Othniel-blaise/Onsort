<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    $data = json_decode(file_get_contents("php://input"));
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    if (!empty($data->email) && !empty($data->password)) {
        
        $query = "SELECT id, full_name, email, password_hash, is_active, is_verified FROM users WHERE email = :email";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":email", $data->email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($data->password, $row['password_hash'])) {
                if ($row['is_active']) {
                    // Générer un token de session
                    $session_token = bin2hex(random_bytes(32));
                    
                    // Enregistrer la session
                    $session_query = "INSERT INTO user_sessions SET 
                                     user_id = :user_id, 
                                     session_token = :session_token, 
                                     ip_address = :ip_address,
                                     device_info = :device_info,
                                     expires_at = DATE_ADD(NOW(), INTERVAL 30 DAY)";
                    $session_stmt = $db->prepare($session_query);
                    $session_stmt->bindParam(":user_id", $row['id']);
                    $session_stmt->bindParam(":session_token", $session_token);
                    $session_stmt->bindParam(":ip_address", $ip_address);
                    $session_stmt->bindParam(":device_info", $user_agent);
                    $session_stmt->execute();
                    
                    // Mettre à jour le dernier login
                    $update_login = "UPDATE users SET last_login = NOW() WHERE id = :id";
                    $update_stmt = $db->prepare($update_login);
                    $update_stmt->bindParam(":id", $row['id']);
                    $update_stmt->execute();
                    
                    // Enregistrer la tentative réussie
                    $log_query = "INSERT INTO login_attempts SET email = :email, ip_address = :ip, user_agent = :agent, success = 1";
                    $log_stmt = $db->prepare($log_query);
                    $log_stmt->bindParam(":email", $data->email);
                    $log_stmt->bindParam(":ip", $ip_address);
                    $log_stmt->bindParam(":agent", $user_agent);
                    $log_stmt->execute();
                    
                    http_response_code(200);
                    echo json_encode(array(
                        "message" => "Connexion réussie",
                        "user" => array(
                            "id" => $row['id'],
                            "full_name" => $row['full_name'],
                            "email" => $row['email'],
                            "is_verified" => $row['is_verified']
                        ),
                        "session_token" => $session_token
                    ));
                } else {
                    http_response_code(401);
                    echo json_encode(array("message" => "Compte désactivé"));
                }
            } else {
                // Enregistrer la tentative échouée
                $log_query = "INSERT INTO login_attempts SET email = :email, ip_address = :ip, user_agent = :agent, success = 0";
                $log_stmt = $db->prepare($log_query);
                $log_stmt->bindParam(":email", $data->email);
                $log_stmt->bindParam(":ip", $ip_address);
                $log_stmt->bindParam(":agent", $user_agent);
                $log_stmt->execute();
                
                http_response_code(401);
                echo json_encode(array("message" => "Email ou mot de passe incorrect"));
            }
        } else {
            http_response_code(401);
            echo json_encode(array("message" => "Email ou mot de passe incorrect"));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Email et mot de passe requis"));
    }
}
?>