<?php
// C:/wamp64/www/onsortx_api/test_connection.php
// Créez ce fichier pour tester votre serveur WAMP

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Test de base
echo json_encode([
    "status" => "success",
    "message" => "Serveur WAMP fonctionne !",
    "timestamp" => date('Y-m-d H:i:s'),
    "server_ip" => $_SERVER['SERVER_ADDR'] ?? 'Unknown',
    "request_method" => $_SERVER['REQUEST_METHOD'],
    "user_agent" => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
]);
?>